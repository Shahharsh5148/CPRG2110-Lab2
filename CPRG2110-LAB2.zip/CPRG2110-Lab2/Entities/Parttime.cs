﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPRG2110_Lab2.Entities
{
    internal class PartTime : Employees
    {
        private double rate;
        public double salary { get { return rate; } }

        public PartTime(string id, string name, string address, double salary)
        {
            this.id = id;
            this.name = name;
            this.address = address;
            this.rate = salary;
        }
    }
}
