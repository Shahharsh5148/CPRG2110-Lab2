﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPRG2110_Lab2.Entities
{
    internal class Employees
    {
        protected string id;
        protected string name;
        protected string address;

        public string ID { get { return id; } }
        public string Name { get { return name; } }
        public string Address { get { return address; } }

        public Employees() { }


        public Employees(string id, string name, string address)
        {
            this.id = id;
            this.name = name;
            this.address = address;
        }

        internal static void Add(Salaried salaried)
        {
            throw new NotImplementedException();
        }
    }
}
