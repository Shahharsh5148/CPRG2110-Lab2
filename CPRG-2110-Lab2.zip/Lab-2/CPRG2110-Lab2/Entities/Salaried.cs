﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPRG2110_Lab2.Entities
{
    internal class Salaried
    {
        private string id;
        private string name;
        private string address;
        private double salaryDouble;

        public Salaried(string id, string name, string address, double salaryDouble)
        {
            this.id = id;
            this.name = name;
            this.address = address;
            this.salaryDouble = salaryDouble;
        }

        internal class salaried : Employees
        {
            private double Salary;
            public double salary { get { return Salary; } }

            public salaried(string id, string name, string address, double Salary) : base(id, name, address)
            {
                this.id = id;
                this.name = name;
                this.address = address;
                this.Salary = salary;
            }

        }
    }
}
