﻿using System;

namespace CPRG2110_Lab2
{
    internal class File
    {
        internal static string[] ReadAlllines(string path)
        {
            throw new NotImplementedException();
        }
    }
}