﻿using CPRG2110_Lab2.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPRG2110_Lab2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Employees> employees = new List<Employees>();
            Employees employee = new Employees();
            string path = "employees.txt";
            string[] lines = File.ReadAlllines(path);

            foreach (string line in lines)
            {
                string[] cells = line.Split(':');

                string id = cells[0];
                string name = cells[1];
                string address = cells[2];

                string firstDigit = id.Substring(0, 1);

                int firstDigitInt = int.Parse(firstDigit);

                if (firstDigitInt >= 0 && firstDigitInt <= 4)
                {
                    //Salaried
                    string salary = cells[7];

                    double salaryDouble = double.Parse(salary);
                    Salaried Salaried = new Salaried(id, name, address, salaryDouble);
                    Employees.Add(Salaried);
                }

                else if (firstDigitInt >= 5 && firstDigitInt <= 7)
                {
                    //Wages
                    string rate = cells[7];
                    string hour = cells[8];
                }
                else if (firstDigitInt >= 8 && firstDigitInt <= 9)
                {
                    //Part time
                    string rate = cells[7];
                    string hour = cells[8];
                }

                /* if(firstDigit == "0" || firstDigit== "1" || firstDigit == "2"|| firstDigit =="3" || firstDigit == "4")
                 {

                 }
                */

            }
        }
    }
}
